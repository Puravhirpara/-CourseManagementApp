# Course Management Application

This is a simple Spring Boot REST API for managing courses.

## Tech Stack
- Java
- Spring Boot
- Spring Data JPA
- MySQL
- REST API

## Features
- Create a new course
- View all courses
- View a single course by ID
- Delete a course

## How to Run
1. Clone the repo
2. Update `application.properties` with your MySQL details
3. Run `CourseManagementApplication.java`
4. Test APIs using Postman.

## Author
Your Name
